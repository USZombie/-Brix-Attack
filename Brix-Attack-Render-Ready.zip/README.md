# Brix Attack

Initial multiplayer Render deployment build.

## Render settings
Build Command: `npm install`
Start Command: `npm start`

The game and WebSocket server are served from the same Render Web Service.
